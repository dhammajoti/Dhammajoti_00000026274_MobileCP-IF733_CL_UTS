export interface Product{
    id: string;
    name : string;
    photoUrl:string[];
    price: number;
    stock: number;
    jenis : string;
    model : string;
    baseClock?:string;
    boostClock?: string;
    jumlahcore?: number;
    thread?: number;
    speed?:string;
    ukuran?: string;
    chipset?: string;
    fitprosesor?: string;
    
    
    
}