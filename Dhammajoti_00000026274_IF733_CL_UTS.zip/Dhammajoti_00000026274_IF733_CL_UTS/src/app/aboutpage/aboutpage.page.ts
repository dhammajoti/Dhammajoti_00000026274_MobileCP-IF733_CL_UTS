import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aboutpage',
  templateUrl: './aboutpage.page.html',
  styleUrls: ['./aboutpage.page.scss'],
})
export class AboutpagePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
