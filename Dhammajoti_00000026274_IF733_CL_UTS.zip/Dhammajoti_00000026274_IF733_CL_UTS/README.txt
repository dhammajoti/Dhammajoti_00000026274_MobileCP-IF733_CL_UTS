Nama	: Dhammajoti
NIM	: 00000026274

Link Github : https://github.com/dhammajoti/Dhammajoti_00000026274_MobileCP-IF733_CL_UTS
Link Hosting : https://uts-mobilecp-dhammajoti-26274.vercel.app/home

Home page : 	- dapat melihat dalam bentuk list dan dalam bentuk grid, untuk merubahnya klik button pada toolbar bagian kanan
   	- pada home dapat melihat product detail, kemudian dapat melakukan slide pada foto product

Side Menu: dapat klik pada button di toolbar bagian kiri dan juga dapat di slide

Admin page : menampilkan list product dan beberapa fungsi seperti berikut.
Edit : pada halaman admin pilih produk yang ingin di edit kemudian slide kiri
Delete : pada halaman admin pilih produk yang ingin di delete kemudian slide kanan
Create : click button + pada toolbar bagian kanan

About app : berisi profil pembuat